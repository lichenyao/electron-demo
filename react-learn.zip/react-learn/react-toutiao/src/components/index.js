import CircleLoading from './CircleLoading'
import DefaultLoading from './DefaultLoading'
import Icon from './Icon-svg'
import PullLoad from './PullLoad'

export default {
    CircleLoading,
    DefaultLoading,
    PullLoad,
    Icon
}