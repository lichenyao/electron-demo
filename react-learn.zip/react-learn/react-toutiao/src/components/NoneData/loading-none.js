import React from 'react'
import Icon from 'components/Icon-svg'
import './index.less'
export default () => (
    <div className="nonedata-wrapper">
        <Icon iconName="SliceCopy"></Icon>
        <span>我也是有底线的</span>
    </div>
)