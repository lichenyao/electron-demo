import React from 'react'
import Icon from 'components/Icon-svg'
import './index.less'
export default () => (
    <div className="nonedata-wrapper2">
        <Icon iconName="icon2"></Icon>
        <span>这家伙太懒！什么也没留下</span>
    </div>
)