# react-toutiao
React 仿写今日头条

## 启动步骤
  ### yarn install / npm install

  ### yarn run dev / npm run dev

  ### yarn run build / npm run build

> [博客地址](http://dzblog.cn/article/5aca31ccd0597d4709f5337a)

> [在线观看地址](http://dzblog.cn/cases/react-toutiao/index.html)